﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NodePade_
{
    public partial class FileName : Form
    {
        public FileName()
        {
            InitializeComponent();
            OKButton.DialogResult = DialogResult.OK;
            try
            {
                this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            }
            catch
            {
                return;
            }
        }

        
    }
}
