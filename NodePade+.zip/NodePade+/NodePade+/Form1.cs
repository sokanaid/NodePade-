﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using NodePade_.Properties;
using FastColoredTextBoxNS;
namespace NodePade_
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// Список открытых файлов.
        /// </summary>
        public List<FileInfo> OpenedFiles = new List<FileInfo>();
        /// <summary>
        /// Список открытых в отдельном окне файлов.
        /// </summary>
        public List<SingleFileForm> SingleWindowOpenedFiles = new List<SingleFileForm>();
        /// <summary>
        /// Массив номеров последних версии.
        /// </summary>
        public List<int> LastVer = new List<int>();
        /// <summary>
        /// Конструктор используемый дочерней формой.
        /// </summary>

        public MainForm(int i)
        {
            InitializeComponent();
        }
        /// <summary>
        /// Конструктор.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();

            // Установка цветовой схемы.
            Color color;
            try
            {
                color = Settings.Default.BackColor;
                if (color == Color.Empty)
                {
                    color = Color.Orange;
                }
            }
            catch
            {
                color = Color.Orange;
            }
            try
            {
                MenuStrip.BackColor = color;
                BackColor = color;

                // Установка настроек автосохранения.
                if (!Settings.Default.AutoSave)
                {
                    AutoSaveOffTool_Click(new object(), new EventArgs());
                }
                else if (Settings.Default.TimerInterval == 30 * 1000)
                {
                    AutoSave30SecTool_Click(new object(), new EventArgs());
                }
                else if (Settings.Default.TimerInterval == 60 * 1000)
                {
                    AutoSave1MinTool_Click(new object(), new EventArgs());
                }
                else
                {
                    AutoSave5MinTool_Click(new object(), new EventArgs());
                }
                // Установка настроек автожурналирования.
                if (!Settings.Default.AutoLog)
                {
                    LoggerOff_Click(new object(), new EventArgs());
                }

                else if (Settings.Default.LogIntervar == 60 * 1000)
                {
                    Loger1minTool_Click(new object(), new EventArgs());
                }
                else
                {
                    Loger5minTool_Click(new object(), new EventArgs());
                }
                // Открытие файлов.
                if (!(Settings.Default.OpenedFiles is null))
                {
                    foreach (var i in Settings.Default.OpenedFiles)
                    {
                        try
                        {
                            OpenFile(new FileInfo(i));
                        }
                        catch
                        {
                            MessageBox.Show($"Не удалось открыть файл {i}", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }
                    }
                }

                if (!(Settings.Default.SingleWindowOpenedFiles is null))
                {
                    foreach (var i in Settings.Default.SingleWindowOpenedFiles)
                    {
                        try
                        {
                            OpenFileNewWindowTool_Click(new FileInfo(i));
                        }
                        catch
                        {
                            MessageBox.Show($"Не удалось открыть файл {i}", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }
                    }
                }
                Settings.Default.Reset();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Открытие нового файла.
        /// </summary>
        public void OpenTool_Click(object sender, EventArgs e)
        {
            try
            {
                if (OpenFileDialog.ShowDialog() == DialogResult.Cancel)
                    return;
                // Чтение файла.
                FileInfo file = new FileInfo(OpenFileDialog.FileName);
                //string fileText = File.ReadAllText(file.FullName);
                OpenFile(file);
                LastVer.Add(0);
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Неправильный формат файла. Если Вы открывали файл формата *.rtf , проверьте, что он был создан корректно (Для создания можно использовать приложение WordPad).");
            }

            catch
            {
                MessageBox.Show("Невозможно открыть файл. Возможно файл уже открыт.");
                return;
            }
        }

        /// <summary>
        /// Чтение и запись файла.
        /// </summary>
        /// <param name="file">Файл.</param>
        public void OpenFile(FileInfo file)
        {
            if (OpenedFiles.Exists(x => x.FullName == file.FullName)) throw new Exception();
            if (SingleWindowOpenedFiles.Exists(x => x.OpenedFiles[0].FullName == file.FullName)) throw new Exception();
            // Создание новой вкладки.
            TabPage newTabPage = new TabPage(file.Name);
            // Добавление тектста на вкладку.
            if (file.Extension.Trim().ToLower() == ".cs")
            {
                FastColoredTextBox newTextBox = new FastColoredTextBox();
                //newTextBox.DelayedEventsInterval = 1000;
                newTextBox.HighlightingRangeType = HighlightingRangeType.AllTextRange;
                newTextBox.Language = Language.CSharp;
                newTextBox.Text = File.ReadAllText(file.FullName);
                newTextBox.Multiline = true;
                
                newTextBox.ContextMenuStrip = ContextMenu;
                newTextBox.Size = newTabPage.ClientSize;
                newTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Left);
                newTabPage.Controls.Add(newTextBox);
            }
            else
            {
                RichTextBox newTextBox = new RichTextBox();
                // Чтение файла в зависимости от расширения.
                if (file.Extension.Trim().ToLower() == ".rtf")
                {
                    newTextBox.LoadFile(file.FullName, RichTextBoxStreamType.RichText);
                }
                else
                {
                    newTextBox.Text = File.ReadAllText(file.FullName);
                }
                newTextBox.Multiline = true;
                newTextBox.ShortcutsEnabled = true;
                newTextBox.ContextMenuStrip = ContextMenu;
                newTextBox.Size = newTabPage.ClientSize;
                newTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Left);
                newTabPage.Controls.Add(newTextBox);
            }
            // Добавление вкладки.
            TabControls.TabPages.Add(newTabPage);
            TabControls.SelectedIndex = TabControls.TabPages.Count - 1;
            OpenedFiles.Add(file);
        }

        /// <summary>
        /// Открытие файла в новом оене.
        /// </summary>
        public void OpenFileNewWindowTool_Click(object sender, EventArgs e)
        {
            try
            {
                SingleFileForm newWindow = new SingleFileForm();
                newWindow.MainWindow = this;
                SingleWindowOpenedFiles.Add(newWindow);
                newWindow.Show();
                newWindow.OpenTool_Click(sender, e);
            }
            catch
            {
                MessageBox.Show("Невозможно открыть файл. Возможно файл уже открыт.");
                return;
            }
        }

        /// <summary>
        /// Открытие файла в новом оене.
        /// </summary>
        public void OpenFileNewWindowTool_Click(FileInfo file)
        {
            SingleFileForm newWindow = new SingleFileForm();
            newWindow.MainWindow = this;
            //this.ForegroundColoreTool.Click += new System.EventHandler(newWindow.ForegroundColoreTool_Click);
            SingleWindowOpenedFiles.Add(newWindow);
            newWindow.Show();
            newWindow.OpenFile(file);
        }

        /// <summary>
        /// Закрытие текущего файла.
        /// </summary>
        public void CloseCurrentFileTool_Click(object sender, EventArgs e)
        {
            try
            {
                FileInfo file = OpenedFiles[TabControls.SelectedIndex];
                DialogResult result = MessageBox.Show("Сохранить изменения?", "Закрытие файла", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    SaveCurrentFileTool_Click(sender, e);
                }
                else if (result != DialogResult.No)
                {
                    return;
                }
                OpenedFiles.RemoveAt(TabControls.SelectedIndex);
                LastVer.RemoveAt(TabControls.SelectedIndex);
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                TabControls.TabPages.Remove(tabPage);
                tabPage.Dispose();
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Файл не выбран", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удается закрыть файл");
            }

        }

        /// <summary>
        /// Сохранение изменений в текущем файле.
        /// </summary>
        public void SaveCurrentFileTool_Click(object sender, EventArgs e)
        {
            try
            {
                FileInfo file = OpenedFiles[TabControls.SelectedIndex];
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (file.Extension.Trim().ToLower() == ".cs")
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    File.WriteAllText(file.FullName, textBox.Text);
                }
                else
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];

                    if (file.Extension.Trim().ToLower() == ".rtf")
                    {

                        textBox.SaveFile(file.FullName, RichTextBoxStreamType.RichText);
                    }
                    else
                    {
                        File.WriteAllText(file.FullName, textBox.Text);
                        //textBox.SaveFile(file.FullName, RichTextBoxStreamType.PlainText);
                    }
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Файл не выбран", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удается сохранить изменения в файле. Проверьте, что файл не открыт в других программах",
                    "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); ; ;
            }

        }


        /// <summary>
        /// Сохранение изменений в заданном файле.
        /// </summary>
        /// <param name="file">Имя файла.</param>
        /// <param name="textBox">Ссылка на контейнер с текстом.</param>
        public void SaveCurrentFileTool_Click(string file, Object textBox)
        {
            try
            {
                if (Path.GetExtension(file).Trim().ToLower() == ".cs")
                {
                    File.WriteAllText(file, ((FastColoredTextBox)textBox).Text);
                }
                else
                {
                    if (Path.GetExtension(file).Trim().ToLower() == ".rtf")
                    {

                        ((RichTextBox)textBox).SaveFile(file, RichTextBoxStreamType.RichText);
                    }
                    else
                    {
                        File.WriteAllText(file, ((RichTextBox)textBox).Text);

                    }
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Файл не выбран", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удается сохранить изменения в файле. Проверьте, что файл не открыт в других программах",
                    "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); ; ;
            }

        }

        /// <summary>
        ///  Копирование выделенного текста в буфер обмена.
        /// </summary>
        public void CopyTextTool_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (tabPage.Controls[0] is RichTextBox)
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                    textBox.Copy();
                }
                else
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    textBox.Copy();
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Сначала выберите фрагмент текста для копироварния.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удалось очистить буфер обмена. Возможно он используется другими процессами.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Вставить текст из буфера обмена.
        /// </summary>
        public void PasteTextTool_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (tabPage.Controls[0] is RichTextBox)
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                    textBox.Paste();
                }
                else
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    textBox.Paste();
                }

            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Сначала выберите место для вставки текста.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удалось извлечь данные из буфера обмена. Возможно он используется другими процессами.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Удалить текст.
        /// </summary>
        public void DeleteTextTool()
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (tabPage.Controls[0] is RichTextBox)
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                    textBox.Text = textBox.Text.Substring(0, textBox.SelectionStart) +
                        textBox.Text.Substring(textBox.SelectionStart + textBox.SelectionLength);
                }
                else
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    textBox.Text = textBox.Text.Substring(0, textBox.SelectionStart) +
                        textBox.Text.Substring(textBox.SelectionStart + textBox.SelectionLength);
                }

            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Сначала выберите место для вставки текста.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удалось удалить текст.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        /// <summary>
        /// Вырезать текст.
        /// </summary>
        public void CutTool_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (tabPage.Controls[0] is RichTextBox)
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                    textBox.Cut();
                }
                else
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    textBox.Cut();
                }
            }
            catch
            {
                MessageBox.Show("Не удалось вырезать текст.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Выбрать весь текст.
        /// </summary>
        public void SelectAllTextTool_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (tabPage.Controls[0] is RichTextBox)
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                    textBox.SelectAll();
                }
                else
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    textBox.SelectAll();
                }

            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Сначала выберите место для вставки текста.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удалось выделить текст.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Изменение формата выделенного текста.
        /// </summary>
        public void FormatTextTool_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                if (tabPage.Controls[0] is RichTextBox)
                {
                    RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                    FontDialog.ShowColor = true;

                    FontDialog.Font = textBox.SelectionFont;
                    FontDialog.Color = textBox.SelectionColor;

                    if (FontDialog.ShowDialog() != DialogResult.Cancel)
                    {
                        textBox.SelectionFont = FontDialog.Font;
                        textBox.SelectionColor = FontDialog.Color;
                    }
                }
                else
                {
                    FastColoredTextBox textBox = (FastColoredTextBox)tabPage.Controls[0];
                    textBox.SelectAll();
                    textBox.DoAutoIndent();

                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Сначала выберите текст.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                // Изменение стиля кода написанного на C# не возможно
                MessageBox.Show("Не удалось отформатировать текст.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Изменение цветовой схемы приложения.
        /// </summary>
        public void ForegroundColoreTool_Click(object sender, EventArgs e)
        {
            try
            {
                ColorDialog.Color = BackColor;
                if (ColorDialog.ShowDialog() != DialogResult.Cancel)
                {
                    MenuStrip.BackColor = ColorDialog.Color;
                    BackColor = ColorDialog.Color;
                }
            }
            catch
            {
                MessageBox.Show("Не удалось установить цветовую схему.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Обработка клавишь быстрого доступа. 
        /// </summary>
        public virtual void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                // Копирование Ctrl+C.
                /*if (e.Control && e.KeyCode == Keys.C)
                {
                    CopyTextTool_Click(sender, e);
                }
                // Вставить Ctrl+V.
                else if (e.Control && e.KeyCode == Keys.V)
                {
                    PasteTextTool_Click(sender, e);
                }
                // Вырезать Ctrl+X.
                else if (e.Control && e.KeyCode == Keys.X)
                {
                    CutTool_Click(sender, e);
                }
                // Выделить весь текст Ctrl+A.
                else if (e.Control && e.KeyCode == Keys.A)
                {
                    SelectAllTextTool_Click(sender, e);
                }
                // Открыть файл в новом окне Ctrl+Shift+O.
                else*/
                if (e.Control && e.KeyCode == Keys.O && e.Shift)
                {
                    OpenFileNewWindowTool_Click(sender, e);
                }
                // Открыть новую вкладку Ctrl+O.
                else if (e.Control && e.KeyCode == Keys.O)
                {
                    OpenTool_Click(sender, e);
                }
                // Сохранить все фалы Ctrl+Shift+S.
                else if (e.Control && e.KeyCode == Keys.S && e.Shift)
                {
                    SaveAllFilesTool_Click(sender, e);
                }
                // Сохранить файл Ctrl+S.
                else if (e.Control && e.KeyCode == Keys.S)
                {
                    SaveCurrentFileTool_Click(sender, e);
                }
                // Закрыть окно Ctrl+Shift+F.
                else if (e.Control && e.KeyCode == Keys.F && e.Shift)
                {
                    this.Close();
                }
                // Закрыть вкладку Ctrl+F.
                else if (e.Control && e.KeyCode == Keys.F)
                {
                    CloseCurrentFileTool_Click(sender, e);
                }
                // Повторение действия Ctrl+Shift+Z.
                else if (e.Control && e.KeyCode == Keys.Z && e.Shift)
                {
                    RedoTool.PerformClick();
                    //RedoTool_Click(sender, e);
                }
                // Отмена действия Ctrlt+Z.
                else if (e.Control && e.KeyCode == Keys.Z)
                {
                    UndoTool.PerformClick();
                    //UndoTool_Click(sender, e);
                }
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Сохранение всех файлов в окне.
        /// </summary>
        public void SaveAllFilesTool_Click(object sender, EventArgs e)
        {
            try
            {
                if (TabControls.TabCount > 0)
                {
                    int ind = TabControls.SelectedIndex;
                    for (int i = 0; i < TabControls.TabPages.Count; i++)
                    {
                        TabControls.SelectedIndex = i;
                        SaveCurrentFileTool_Click(sender, e);
                    }
                    TabControls.SelectedIndex = ind;
                }
                if (SingleWindowOpenedFiles.Count > 0)
                {
                    foreach (var form in SingleWindowOpenedFiles)
                    {
                        form.SaveAllFilesTool_Click(form, e);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить все фалы.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Закрытие формы.
        /// </summary>
        public void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (TabControls.TabCount > 0 || SingleWindowOpenedFiles.Count > 0)
                {
                    DialogResult result = MessageBox.Show("В открытых файлах есть несохраненные изменения. Сохранить их?", "Закрытие файла", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        SaveAllFilesTool_Click(sender, e);
                    }
                    else if (result == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }


                // Сохранение цветовой схемы.
                Settings.Default.BackColor = this.BackColor;
                // Сохранение файлов.
                if (Settings.Default.OpenedFiles is null)
                {
                    Settings.Default.OpenedFiles = new System.Collections.Specialized.StringCollection();
                }
                Settings.Default.OpenedFiles.Clear();
                foreach (var i in OpenedFiles)
                {
                    Settings.Default.OpenedFiles.Add(i.FullName);
                }
                // Сохранение настроек автосохранения.
                Settings.Default.AutoSave = SaveTimer.Enabled;
                Settings.Default.TimerInterval = SaveTimer.Interval;
                Settings.Default.AutoLog = LogTimer.Enabled;
                Settings.Default.LogIntervar = LogTimer.Interval;

                // Сохранение открытых в отдельных окнах файлов.
                if (Settings.Default.SingleWindowOpenedFiles is null)
                {
                    Settings.Default.SingleWindowOpenedFiles = new System.Collections.Specialized.StringCollection();
                }
                Settings.Default.SingleWindowOpenedFiles.Clear();
                foreach (var form in SingleWindowOpenedFiles)
                {
                    Settings.Default.SingleWindowOpenedFiles.Add(form.OpenedFiles[0].FullName);
                }
                /// Удаление версий закрытых файлов.
                try
                {
                    List<string> Files = new List<string>();
                    for (int i = 0; i < OpenedFiles.Count; i++)
                    {
                        Files.Add(OpenedFiles[i].FullName.GetHashCode().ToString());

                    }
                    foreach (var i in SingleWindowOpenedFiles)
                    {
                        Files.Add(i.OpenedFiles[0].GetHashCode().ToString());

                    }

                    foreach (var dir in Directory.GetDirectories("Logs"))
                    {
                        if (!Files.Exists(x => x == Path.GetFileName(dir)))
                        {
                            foreach (var f in Directory.GetFiles(dir))
                            {
                                File.Delete(f);
                            }
                            Directory.Delete(dir);
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Не удалось корректно сохранить копии.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
            catch
            {
                Settings.Default.BackColor = Color.Orange;
            }

            Settings.Default.Save();

        }
        public void AutoSaveOffTool_Click(object sender, EventArgs e)
        {
            try
            {
                SaveTimer.Enabled = false;

                AutoSave1MinTool.Checked = false;
                AutoSave5MinTool.Checked = false;
                AutoSave30SecTool.Checked = false;
                AutoSaveOffTool.Checked = true;
                SaveTimer.Stop();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        ///Автосохранение раз в минуту. 
        /// </summary>
        public void AutoSave1MinTool_Click(object sender, EventArgs e)
        {
            try
            {
                SaveTimer.Interval = 60 * 1000;
                SaveTimer.Enabled = true;

                AutoSave1MinTool.Checked = true;
                AutoSave5MinTool.Checked = false;
                AutoSave30SecTool.Checked = false;
                AutoSaveOffTool.Checked = false;
                SaveTimer.Start();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        // Автосохранение раз в 30 секунд.
        /// </summary>
        public void AutoSave30SecTool_Click(object sender, EventArgs e)
        {
            try
            {
                SaveTimer.Interval = 30 * 1000;
                SaveTimer.Enabled = true;

                AutoSave1MinTool.Checked = false;
                AutoSave5MinTool.Checked = false;
                AutoSave30SecTool.Checked = true;
                AutoSaveOffTool.Checked = false;
                SaveTimer.Start();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        // Автосохранение раз в 5 минут.
        /// </summary>
        public void AutoSave5MinTool_Click(object sender, EventArgs e)
        {
            try
            {
                SaveTimer.Interval = 5 * 60 * 1000;
                SaveTimer.Enabled = true;

                AutoSave1MinTool.Checked = false;
                AutoSave5MinTool.Checked = true;
                AutoSave30SecTool.Checked = false;
                AutoSaveOffTool.Checked = false;
                SaveTimer.Start();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Отмена последнего действия в файле.
        /// </summary>
        public void UndoTool_Click(object sender, EventArgs e)
        {
            try
            {
                FileInfo file = OpenedFiles[TabControls.SelectedIndex];
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                tabPage.Focus();
                textBox.Undo();
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Файл не выбран", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удается отменить действие в файле.",
                    "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Повторение последнего действия в файле.
        /// </summary>
        public void RedoTool_Click(object sender, EventArgs e)
        {
            try
            {
                FileInfo file = OpenedFiles[TabControls.SelectedIndex];
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                tabPage.Focus();
                textBox.Redo();
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Файл не выбран", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удается повторить действие в файле.",
                    "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Закрытие текущего окна.
        /// </summary>
        private void CloseAppTool_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Создание файла.
        /// </summary>
        private void CreateFileTool_Click(object sender, EventArgs e)
        {
            try
            {
                FileInfo file = CreateFileTool_Click();
                if (file is null)
                    return;
                OpenFile(file);
            }
            catch
            {
                MessageBox.Show("Не удалось создать файл.",
                    "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Создание файла.
        /// </summary>
        private FileInfo CreateFileTool_Click()
        {
            try
            {
                DialogResult result = SaveDialog.ShowDialog();
                if (result != DialogResult.OK)
                {
                    return null;
                }

                string directory = SaveDialog.SelectedPath;
                FileName form = new FileName();
                while (true)
                {
                    if (form.ShowDialog() != DialogResult.OK)
                    {
                        return null;
                    }
                    string fileName = form.FilePath.Text.Trim() + "." + form.Exect.Text.Trim();
                    if (File.Exists(Path.Combine(directory, fileName)))
                    {
                        MessageBox.Show("Файл с таким именем уже существует.", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        continue;
                    }
                    try
                    {
                        if (form.Exect.Text.Trim() == "rtf")
                        {
                            File.WriteAllText(Path.Combine(directory, fileName), @"{\rtf1\ansi\ansicpg1252\deff0\nouicompat\deflang14346{\fonttbl{\f0\fnil\fcharset0 Calibri;}}" +
                                @"{\*\generator Riched20 10.0.10586}\viewkind4\uc1 \pard\sa200\sl276\slmult1\f0\fs22\lang10  }");
                        }
                        else
                        {
                            File.WriteAllText(Path.Combine(directory, fileName), "");

                        }
                        FileInfo file = new FileInfo(Path.Combine(directory, fileName));
                        return file;
                    }
                    catch
                    {
                        MessageBox.Show("Некорректное имя файла или расширение.", "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        continue;
                    }
                }
            }

            catch
            {
                return null;
            }


        }

        /// <summary>
        /// Создание файла в новом окне.
        /// </summary>
        private void CreateFileNewWindowTool_Click(object sender, EventArgs e)
        {
            try
            {
                FileInfo file = CreateFileTool_Click();
                if (file is null)
                    return;

                SingleFileForm newWindow = new SingleFileForm();
                newWindow.MainWindow = this;
                SingleWindowOpenedFiles.Add(newWindow);
                newWindow.Show();
                newWindow.OpenFile(file);
            }
            catch
            {
                MessageBox.Show("Не удалось создать файл.",
                    "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Сохранение версии.
        /// </summary>
        private void SaveVerTool_Click(object sender, EventArgs e)
        {
            try
            {
                LastVer[TabControls.SelectedIndex] = SaveVerTool_Click(OpenedFiles[TabControls.SelectedIndex].FullName, LastVer[TabControls.SelectedIndex]);

            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Файл не выбран.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch
            {
                MessageBox.Show("Не удалось сохранить версию.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }


        /// <summary>
        /// Сохранение версии.
        /// </summary>
        /// <param name="file">Полный путь файла</param>
        /// <param name="numb">Номер последней версии</param>
        public int SaveVerTool_Click(string file, int numb)
        {

            string directory = Path.Combine("Logs", file.GetHashCode().ToString());
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
            /*if (numb == 5)
            {
                File.Delete(Path.Combine(directory, "1" + Path.GetExtension(file)));
                numb--;
            }*/
            File.Copy(file, Path.Combine(directory, (++numb).ToString() + Path.GetExtension(file)));
            return numb;

        }

        /// <summary>
        /// Остановка автожурналирования.
        /// </summary>
        private void LoggerOff_Click(object sender, EventArgs e)
        {
            try
            {
                LogTimer.Enabled = false;

                Loger1minTool.Checked = false;
                Loger5minTool.Checked = false;
                LoggerOff.Checked = true;
                LogTimer.Stop();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Автожурналирование раз в минуту.
        /// </summary>
        public void Loger1minTool_Click(object sender, EventArgs e)
        {
            try
            {

                LogTimer.Interval = 60 * 1000;
                LogTimer.Enabled = true;


                Loger1minTool.Checked = true;
                Loger5minTool.Checked = false;
                LoggerOff.Checked = false;
                LogTimer.Start();
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Автожурналирование раз в 5 минут.
        /// </summary>
        public void Loger5minTool_Click(object sender, EventArgs e)
        {
            try
            {
                LogTimer.Interval = 5 * 60 * 1000;
                LogTimer.Enabled = true;

                Loger1minTool.Checked = false;
                Loger5minTool.Checked = true;
                LoggerOff.Checked = false;
                LogTimer.Start();
            }
            catch
            {
                return;
            }

        }

        /// <summary>
        /// Возвращение к предыдущей версии.
        /// </summary>
        private void LastVerTool_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage tabPage = TabControls.TabPages[TabControls.SelectedIndex];
                RichTextBox textBox = (RichTextBox)tabPage.Controls[0];
                if (LastVer[TabControls.SelectedIndex] <= 0)
                {
                    MessageBox.Show("Нет сохраненных версий.", "Отмена операции",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string file = Path.Combine("Logs", OpenedFiles[TabControls.SelectedIndex].FullName.GetHashCode().ToString(), LastVer[TabControls.SelectedIndex].ToString() +
                    Path.GetExtension(OpenedFiles[TabControls.SelectedIndex].FullName));
                if (Path.GetExtension(file).Trim().ToLower() == ".rtf")
                {

                    textBox.LoadFile(file);
                    textBox.SaveFile(OpenedFiles[TabControls.SelectedIndex].FullName);
                }
                else
                {
                    textBox.Text = File.ReadAllText(file);
                    File.WriteAllText(OpenedFiles[TabControls.SelectedIndex].FullName, textBox.Text);
                }
                LastVer[TabControls.SelectedIndex]--;
                File.Delete(file);


            }
            catch
            {
                MessageBox.Show("Не удалось открыть предыдущую версию.",
                   "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        /// <summary>
        /// Журналирование всех файлов.
        /// </summary>
        private void LogTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                foreach (var form in SingleWindowOpenedFiles)
                {
                    form.LastVer[0] = SaveVerTool_Click(form.OpenedFiles[0].FullName, form.LastVer[0]);
                }
                for (int i = 0; i < OpenedFiles.Count; i++)
                {
                    LastVer[i] = SaveVerTool_Click(OpenedFiles[i].FullName, LastVer[i]);
                }
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить версии файлов.",
                  "Отмена операции", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
