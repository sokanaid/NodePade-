﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

using NodePade_.Properties;

namespace NodePade_
{
    public partial class SingleFileForm : MainForm
    {
        public MainForm MainWindow;
        public SingleFileForm() : base(1)
        {
            InitializeComponent();
            //this.TopLevel = false;
            // Сокрытие некоторых компонентов.
            try
            {
                
                AutoSaveTool.Visible = false;
                OpenTool.Visible = false;
                OpenFileNewWindowTool.Visible = false;
                SaveAllFilesTool.Visible = false;
                CloseCurrentFileTool.Visible = false;
                AutoLogTool.Visible = false;
                this.FormClosing -= MainForm_FormClosing;
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Обработка клавишь быстрого доступа. 
        /// </summary>
        public override void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                /*// Копирование Ctrl+C.
                if (e.Control && e.KeyCode == Keys.C)
                {
                    CopyTextTool_Click(sender, e);
                }
                // Вставить Ctrl+V.
                else if (e.Control && e.KeyCode == Keys.V)
                {
                    this.PasteTextTool_Click(sender, e);
                }
                // Вырезать Ctrl+X.
                else if (e.Control && e.KeyCode == Keys.X)
                {
                    CutTool_Click(sender, e);
                }
                // Выделить весь текст Ctrl+A.
                else if (e.Control && e.KeyCode == Keys.A)
                {
                    SelectAllTextTool_Click(sender, e);
                }
                // Открыть новую вкладку Ctrl+O.
                else */
                if (e.Control && e.KeyCode == Keys.O)
                {
                    MessageBox.Show("Открытие новых файлов возможно только из главного окна");
                }
                // Сохранить файл Ctrl+S.
                else if (e.Control && e.KeyCode == Keys.S)
                {
                    SaveCurrentFileTool_Click(sender, e);
                }
                // Закрыть вкладку Ctrl+F.
                else if (e.Control && e.KeyCode == Keys.F)
                {
                    this.Close();
                }
                // Повторение действия Ctrl+Shift+Z.
                else if (e.Control && e.KeyCode == Keys.Z && e.Shift)
                {
                    RedoTool.PerformClick();
                }
                // Отмена действия Ctrlt+Z.
                else if (e.Control && e.KeyCode == Keys.Z)
                {
                    UndoTool.PerformClick();
                }
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Открытие нового файла.
        /// </summary>
        public new void OpenTool_Click(object sender, EventArgs e)
        {
            try
            {
                if (OpenFileDialog.ShowDialog() == DialogResult.Cancel)
                {
                    this.Close();
                    return;
                }
                // Чтение файла.
                FileInfo file = new FileInfo(OpenFileDialog.FileName);
                OpenFile(file);
                LastVer.Add(0);

            }
            catch (ArgumentException)
            {
                MessageBox.Show("Неправильный формат файла. Если Вы открывали файл формата *.rtf , проверьте, что он был создан корректно (Для создания можно использовать приложение WordPad)");
                this.Close();
            }
            catch
            {
                MessageBox.Show("Невозможно открыть файл. Возможно файл уже открыт.");
                this.Close();
                return;
            }
        }

        /// <summary>
        /// Загрузка формы.
        /// </summary>
        private void SingleFileForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.BackColor = MainWindow.BackColor;
                this.MenuStrip.BackColor = this.BackColor;
            }
            catch
            {
                return;
            }
        }

        /// <summary>
        /// Закрытие формы.
        /// </summary>
        private void SingleFileForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Форму закрыывает пользователь.
            try
            {
                if (TabControls.TabCount > 0)
                {
                    DialogResult result = MessageBox.Show("В открытом файле есть несохраненные изменения. Сохранить их?", "Закрытие файла", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        SaveAllFilesTool_Click(sender, e);
                    }
                    else if (result == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        return;
                    }

                }
                if (e.CloseReason == CloseReason.UserClosing)
                {
                    MainWindow.SingleWindowOpenedFiles.Remove(this);
                }
            }
            catch
            {
                return;
            }
        }


    }
}
