﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using NodePade_.Properties;
namespace NodePade_
{
    partial class SingleFileForm:MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        public System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public  void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "Имя файла";
            this.OpenFileDialog.Filter = "Text files (*.txt, *.rtf)|*.txt;*.rtf|C# файлы (*.cs)|*.cs|Все файлы|*.*";
            // 
            // SingleFileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "SingleFileForm";
            this.Text = "Файл";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SingleFileForm_FormClosing);
            this.Load += new System.EventHandler(this.SingleFileForm_Load);
            this.Controls.SetChildIndex(this.TabControls, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        
        #endregion
    }
}