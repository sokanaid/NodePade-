﻿
namespace NodePade_
{
    partial class FileName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FilePath = new System.Windows.Forms.TextBox();
            this.PointLable = new System.Windows.Forms.Label();
            this.TextLable = new System.Windows.Forms.Label();
            this.CanselButton = new System.Windows.Forms.Button();
            this.OKButton = new System.Windows.Forms.Button();
            this.Exect = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // FilePath
            // 
            this.FilePath.Location = new System.Drawing.Point(1, 102);
            this.FilePath.Name = "FilePath";
            this.FilePath.Size = new System.Drawing.Size(273, 26);
            this.FilePath.TabIndex = 0;
            // 
            // PointLable
            // 
            this.PointLable.AutoSize = true;
            this.PointLable.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PointLable.Location = new System.Drawing.Point(279, 84);
            this.PointLable.Name = "PointLable";
            this.PointLable.Size = new System.Drawing.Size(27, 45);
            this.PointLable.TabIndex = 1;
            this.PointLable.Text = ".";
            // 
            // TextLable
            // 
            this.TextLable.AutoSize = true;
            this.TextLable.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TextLable.ForeColor = System.Drawing.Color.Firebrick;
            this.TextLable.Location = new System.Drawing.Point(12, 23);
            this.TextLable.Name = "TextLable";
            this.TextLable.Size = new System.Drawing.Size(385, 32);
            this.TextLable.TabIndex = 2;
            this.TextLable.Text = "Введите имя фала и расширение:";
            // 
            // CanselButton
            // 
            this.CanselButton.Location = new System.Drawing.Point(312, 166);
            this.CanselButton.Name = "CanselButton";
            this.CanselButton.Size = new System.Drawing.Size(90, 28);
            this.CanselButton.TabIndex = 3;
            this.CanselButton.Text = "Отмена";
            this.CanselButton.UseVisualStyleBackColor = true;
            // 
            // OKButton
            // 
            this.OKButton.Location = new System.Drawing.Point(184, 166);
            this.OKButton.Name = "OKButton";
            this.OKButton.Size = new System.Drawing.Size(90, 28);
            this.OKButton.TabIndex = 4;
            this.OKButton.Text = "OK";
            this.OKButton.UseVisualStyleBackColor = true;
            // 
            // Exect
            // 
            this.Exect.Location = new System.Drawing.Point(312, 102);
            this.Exect.Name = "Exect";
            this.Exect.Size = new System.Drawing.Size(87, 26);
            this.Exect.TabIndex = 5;
            this.Exect.Text = "txt";
            // 
            // FileName
            // 
            this.AcceptButton = this.OKButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CanselButton;
            this.ClientSize = new System.Drawing.Size(420, 206);
            this.Controls.Add(this.Exect);
            this.Controls.Add(this.OKButton);
            this.Controls.Add(this.CanselButton);
            this.Controls.Add(this.TextLable);
            this.Controls.Add(this.PointLable);
            this.Controls.Add(this.FilePath);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FileName";
            this.Text = "Имя файла";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label PointLable;
        private System.Windows.Forms.Label TextLable;
        private System.Windows.Forms.Button CanselButton;
        private System.Windows.Forms.Button OKButton;
        public System.Windows.Forms.TextBox FilePath;
        public System.Windows.Forms.TextBox Exect;
    }
}