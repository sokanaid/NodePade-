﻿
namespace NodePade_
{
    partial class MainForm
    {

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TabControls = new System.Windows.Forms.TabControl();
            this.ContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CopyToolContextMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.CutToolContextMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.PasteToolContextMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAllTextContextMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.FormatToolContextMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.FielTool = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenTool = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFileNewWindowTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CloseCurrentFileTool = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveCurrentFileTool = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveAllFilesTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CloseAppTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateFileTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CreateFileNewWindowTool = new System.Windows.Forms.ToolStripMenuItem();
            this.EditTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CopyTextTool = new System.Windows.Forms.ToolStripMenuItem();
            this.PasteTextTool = new System.Windows.Forms.ToolStripMenuItem();
            this.CutTextTool = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAllTextTool = new System.Windows.Forms.ToolStripMenuItem();
            this.UndoTool = new System.Windows.Forms.ToolStripMenuItem();
            this.RedoTool = new System.Windows.Forms.ToolStripMenuItem();
            this.FormatTool = new System.Windows.Forms.ToolStripMenuItem();
            this.FormatTextTool = new System.Windows.Forms.ToolStripMenuItem();
            this.SettingsTool = new System.Windows.Forms.ToolStripMenuItem();
            this.ForegroundColoreTool = new System.Windows.Forms.ToolStripMenuItem();
            this.AutoSaveTool = new System.Windows.Forms.ToolStripMenuItem();
            this.AutoSaveOffTool = new System.Windows.Forms.ToolStripMenuItem();
            this.AutoSave1MinTool = new System.Windows.Forms.ToolStripMenuItem();
            this.AutoSave5MinTool = new System.Windows.Forms.ToolStripMenuItem();
            this.AutoSave30SecTool = new System.Windows.Forms.ToolStripMenuItem();
            this.LoggerTool = new System.Windows.Forms.ToolStripMenuItem();
            this.LastVerTool = new System.Windows.Forms.ToolStripMenuItem();
            this.AutoLogTool = new System.Windows.Forms.ToolStripMenuItem();
            this.Loger1minTool = new System.Windows.Forms.ToolStripMenuItem();
            this.Loger5minTool = new System.Windows.Forms.ToolStripMenuItem();
            this.LoggerOff = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveVerTool = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.FontDialog = new System.Windows.Forms.FontDialog();
            this.ColorDialog = new System.Windows.Forms.ColorDialog();
            this.SaveTimer = new System.Windows.Forms.Timer(this.components);
            this.SaveDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.LogTimer = new System.Windows.Forms.Timer(this.components);
            this.ContextMenu.SuspendLayout();
            this.MenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControls
            // 
            this.TabControls.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TabControls.ContextMenuStrip = this.ContextMenu;
            this.TabControls.HotTrack = true;
            this.TabControls.Location = new System.Drawing.Point(4, 31);
            this.TabControls.Name = "TabControls";
            this.TabControls.SelectedIndex = 0;
            this.TabControls.ShowToolTips = true;
            this.TabControls.Size = new System.Drawing.Size(795, 407);
            this.TabControls.TabIndex = 0;
            // 
            // ContextMenu
            // 
            this.ContextMenu.ImageScalingSize = new System.Drawing.Size(19, 19);
            this.ContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopyToolContextMenu,
            this.CutToolContextMenu,
            this.PasteToolContextMenu,
            this.SelectAllTextContextMenu,
            this.FormatToolContextMenu});
            this.ContextMenu.Name = "contextMenuStrip1";
            this.ContextMenu.Size = new System.Drawing.Size(264, 124);
            this.ContextMenu.Click += new System.EventHandler(this.FormatTextTool_Click);
            // 
            // CopyToolContextMenu
            // 
            this.CopyToolContextMenu.Name = "CopyToolContextMenu";
            this.CopyToolContextMenu.ShortcutKeyDisplayString = "Ctrl+C";
            this.CopyToolContextMenu.Size = new System.Drawing.Size(263, 24);
            this.CopyToolContextMenu.Text = "Копировать";
            this.CopyToolContextMenu.Click += new System.EventHandler(this.CopyTextTool_Click);
            // 
            // CutToolContextMenu
            // 
            this.CutToolContextMenu.Name = "CutToolContextMenu";
            this.CutToolContextMenu.ShortcutKeyDisplayString = "Ctrl+X";
            this.CutToolContextMenu.Size = new System.Drawing.Size(263, 24);
            this.CutToolContextMenu.Text = "Вырезать";
            this.CutToolContextMenu.Click += new System.EventHandler(this.CutTool_Click);
            // 
            // PasteToolContextMenu
            // 
            this.PasteToolContextMenu.Name = "PasteToolContextMenu";
            this.PasteToolContextMenu.ShortcutKeyDisplayString = "Ctrl+V";
            this.PasteToolContextMenu.Size = new System.Drawing.Size(263, 24);
            this.PasteToolContextMenu.Text = "Вставить";
            this.PasteToolContextMenu.Click += new System.EventHandler(this.PasteTextTool_Click);
            // 
            // SelectAllTextContextMenu
            // 
            this.SelectAllTextContextMenu.Name = "SelectAllTextContextMenu";
            this.SelectAllTextContextMenu.ShortcutKeyDisplayString = "Ctrl+A";
            this.SelectAllTextContextMenu.Size = new System.Drawing.Size(263, 24);
            this.SelectAllTextContextMenu.Text = "Выбрать весь текст";
            this.SelectAllTextContextMenu.Click += new System.EventHandler(this.SelectAllTextTool_Click);
            // 
            // FormatToolContextMenu
            // 
            this.FormatToolContextMenu.Name = "FormatToolContextMenu";
            this.FormatToolContextMenu.Size = new System.Drawing.Size(263, 24);
            this.FormatToolContextMenu.Text = "Настройка формата текста";
            // 
            // MenuStrip
            // 
            this.MenuStrip.ImageScalingSize = new System.Drawing.Size(19, 19);
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FielTool,
            this.EditTool,
            this.FormatTool,
            this.SettingsTool});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.Size = new System.Drawing.Size(800, 28);
            this.MenuStrip.TabIndex = 1;
            this.MenuStrip.Text = "menu";
            // 
            // FielTool
            // 
            this.FielTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenTool,
            this.OpenFileNewWindowTool,
            this.CloseCurrentFileTool,
            this.SaveCurrentFileTool,
            this.SaveAllFilesTool,
            this.CloseAppTool,
            this.CreateFileTool,
            this.CreateFileNewWindowTool});
            this.FielTool.Name = "FielTool";
            this.FielTool.Size = new System.Drawing.Size(59, 24);
            this.FielTool.Text = "Файл";
            // 
            // OpenTool
            // 
            this.OpenTool.Name = "OpenTool";
            this.OpenTool.ShortcutKeyDisplayString = "Ctrl+O";
            this.OpenTool.Size = new System.Drawing.Size(380, 26);
            this.OpenTool.Text = "Открыть файл";
            this.OpenTool.Click += new System.EventHandler(this.OpenTool_Click);
            // 
            // OpenFileNewWindowTool
            // 
            this.OpenFileNewWindowTool.Name = "OpenFileNewWindowTool";
            this.OpenFileNewWindowTool.ShortcutKeyDisplayString = "Ctrl+Shift+O";
            this.OpenFileNewWindowTool.Size = new System.Drawing.Size(380, 26);
            this.OpenFileNewWindowTool.Text = "Открыть файл в новом окне";
            this.OpenFileNewWindowTool.Click += new System.EventHandler(this.OpenFileNewWindowTool_Click);
            // 
            // CloseCurrentFileTool
            // 
            this.CloseCurrentFileTool.Name = "CloseCurrentFileTool";
            this.CloseCurrentFileTool.ShortcutKeyDisplayString = "Ctrl+F";
            this.CloseCurrentFileTool.Size = new System.Drawing.Size(380, 26);
            this.CloseCurrentFileTool.Text = "Закрыть файл";
            this.CloseCurrentFileTool.Click += new System.EventHandler(this.CloseCurrentFileTool_Click);
            // 
            // SaveCurrentFileTool
            // 
            this.SaveCurrentFileTool.Name = "SaveCurrentFileTool";
            this.SaveCurrentFileTool.ShortcutKeyDisplayString = "Ctrl+S";
            this.SaveCurrentFileTool.Size = new System.Drawing.Size(380, 26);
            this.SaveCurrentFileTool.Text = "Сохранить файл";
            this.SaveCurrentFileTool.Click += new System.EventHandler(this.SaveCurrentFileTool_Click);
            // 
            // SaveAllFilesTool
            // 
            this.SaveAllFilesTool.Name = "SaveAllFilesTool";
            this.SaveAllFilesTool.ShortcutKeyDisplayString = "Ctrl+Shift+S";
            this.SaveAllFilesTool.Size = new System.Drawing.Size(380, 26);
            this.SaveAllFilesTool.Text = "Сохранить все фалы ";
            this.SaveAllFilesTool.Click += new System.EventHandler(this.SaveAllFilesTool_Click);
            // 
            // CloseAppTool
            // 
            this.CloseAppTool.Name = "CloseAppTool";
            this.CloseAppTool.ShortcutKeyDisplayString = "Ctrl+Shift+F";
            this.CloseAppTool.Size = new System.Drawing.Size(380, 26);
            this.CloseAppTool.Text = "Закрыть окно";
            this.CloseAppTool.Click += new System.EventHandler(this.CloseAppTool_Click);
            // 
            // CreateFileTool
            // 
            this.CreateFileTool.Name = "CreateFileTool";
            this.CreateFileTool.ShortcutKeyDisplayString = "Ctrl+N";
            this.CreateFileTool.Size = new System.Drawing.Size(380, 26);
            this.CreateFileTool.Text = "Создать файл";
            this.CreateFileTool.Click += new System.EventHandler(this.CreateFileTool_Click);
            // 
            // CreateFileNewWindowTool
            // 
            this.CreateFileNewWindowTool.Name = "CreateFileNewWindowTool";
            this.CreateFileNewWindowTool.ShortcutKeyDisplayString = "Ctrl+Shift+N";
            this.CreateFileNewWindowTool.Size = new System.Drawing.Size(380, 26);
            this.CreateFileNewWindowTool.Text = "Создать файл в новом окне";
            this.CreateFileNewWindowTool.Click += new System.EventHandler(this.CreateFileNewWindowTool_Click);
            // 
            // EditTool
            // 
            this.EditTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopyTextTool,
            this.PasteTextTool,
            this.CutTextTool,
            this.SelectAllTextTool,
            this.UndoTool,
            this.RedoTool});
            this.EditTool.Name = "EditTool";
            this.EditTool.Size = new System.Drawing.Size(74, 24);
            this.EditTool.Text = "Правка";
            // 
            // CopyTextTool
            // 
            this.CopyTextTool.Name = "CopyTextTool";
            this.CopyTextTool.ShortcutKeyDisplayString = "Ctrl+C";
            this.CopyTextTool.Size = new System.Drawing.Size(324, 26);
            this.CopyTextTool.Text = "Копировать";
            this.CopyTextTool.Click += new System.EventHandler(this.CopyTextTool_Click);
            // 
            // PasteTextTool
            // 
            this.PasteTextTool.Name = "PasteTextTool";
            this.PasteTextTool.ShortcutKeyDisplayString = "Ctrl+V";
            this.PasteTextTool.Size = new System.Drawing.Size(324, 26);
            this.PasteTextTool.Text = "Вставить";
            this.PasteTextTool.Click += new System.EventHandler(this.PasteTextTool_Click);
            // 
            // CutTextTool
            // 
            this.CutTextTool.BackColor = System.Drawing.SystemColors.Control;
            this.CutTextTool.Name = "CutTextTool";
            this.CutTextTool.ShortcutKeyDisplayString = "Ctrl+X";
            this.CutTextTool.Size = new System.Drawing.Size(324, 26);
            this.CutTextTool.Text = "Вырезать";
            this.CutTextTool.Click += new System.EventHandler(this.CutTool_Click);
            // 
            // SelectAllTextTool
            // 
            this.SelectAllTextTool.Name = "SelectAllTextTool";
            this.SelectAllTextTool.ShortcutKeyDisplayString = "Ctrl+A";
            this.SelectAllTextTool.Size = new System.Drawing.Size(324, 26);
            this.SelectAllTextTool.Text = "Выбрать весь текст";
            this.SelectAllTextTool.Click += new System.EventHandler(this.SelectAllTextTool_Click);
            // 
            // UndoTool
            // 
            this.UndoTool.Name = "UndoTool";
            this.UndoTool.ShortcutKeyDisplayString = "Ctrl+Z";
            this.UndoTool.Size = new System.Drawing.Size(324, 26);
            this.UndoTool.Text = "Отменить действие";
            this.UndoTool.Click += new System.EventHandler(this.UndoTool_Click);
            // 
            // RedoTool
            // 
            this.RedoTool.Name = "RedoTool";
            this.RedoTool.ShortcutKeyDisplayString = "Ctrl+Shift+Z";
            this.RedoTool.Size = new System.Drawing.Size(324, 26);
            this.RedoTool.Text = "Повторить действие";
            this.RedoTool.Click += new System.EventHandler(this.RedoTool_Click);
            // 
            // FormatTool
            // 
            this.FormatTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FormatTextTool});
            this.FormatTool.Name = "FormatTool";
            this.FormatTool.Size = new System.Drawing.Size(77, 24);
            this.FormatTool.Text = "Формат";
            // 
            // FormatTextTool
            // 
            this.FormatTextTool.Name = "FormatTextTool";
            this.FormatTextTool.Size = new System.Drawing.Size(276, 26);
            this.FormatTextTool.Text = "Настройка формата текста";
            this.FormatTextTool.Click += new System.EventHandler(this.FormatTextTool_Click);
            // 
            // SettingsTool
            // 
            this.SettingsTool.BackColor = System.Drawing.Color.WhiteSmoke;
            this.SettingsTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ForegroundColoreTool,
            this.AutoSaveTool,
            this.LoggerTool});
            this.SettingsTool.Name = "SettingsTool";
            this.SettingsTool.Size = new System.Drawing.Size(98, 24);
            this.SettingsTool.Text = "Настройки";
            this.SettingsTool.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // ForegroundColoreTool
            // 
            this.ForegroundColoreTool.Name = "ForegroundColoreTool";
            this.ForegroundColoreTool.Size = new System.Drawing.Size(275, 26);
            this.ForegroundColoreTool.Text = "Изменить цветовую схему";
            this.ForegroundColoreTool.Click += new System.EventHandler(this.ForegroundColoreTool_Click);
            // 
            // AutoSaveTool
            // 
            this.AutoSaveTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AutoSaveOffTool,
            this.AutoSave1MinTool,
            this.AutoSave5MinTool,
            this.AutoSave30SecTool});
            this.AutoSaveTool.Name = "AutoSaveTool";
            this.AutoSaveTool.Size = new System.Drawing.Size(275, 26);
            this.AutoSaveTool.Text = "Автосохранение";
            // 
            // AutoSaveOffTool
            // 
            this.AutoSaveOffTool.Checked = true;
            this.AutoSaveOffTool.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoSaveOffTool.Name = "AutoSaveOffTool";
            this.AutoSaveOffTool.Size = new System.Drawing.Size(196, 26);
            this.AutoSaveOffTool.Text = "Выключено";
            this.AutoSaveOffTool.Click += new System.EventHandler(this.AutoSaveOffTool_Click);
            // 
            // AutoSave1MinTool
            // 
            this.AutoSave1MinTool.Name = "AutoSave1MinTool";
            this.AutoSave1MinTool.Size = new System.Drawing.Size(196, 26);
            this.AutoSave1MinTool.Text = "Раз в минуту";
            this.AutoSave1MinTool.Click += new System.EventHandler(this.AutoSave1MinTool_Click);
            // 
            // AutoSave5MinTool
            // 
            this.AutoSave5MinTool.Name = "AutoSave5MinTool";
            this.AutoSave5MinTool.Size = new System.Drawing.Size(196, 26);
            this.AutoSave5MinTool.Text = "Раз в 5 минут";
            this.AutoSave5MinTool.Click += new System.EventHandler(this.AutoSave5MinTool_Click);
            // 
            // AutoSave30SecTool
            // 
            this.AutoSave30SecTool.Name = "AutoSave30SecTool";
            this.AutoSave30SecTool.Size = new System.Drawing.Size(196, 26);
            this.AutoSave30SecTool.Text = "Раз в 30 секунд";
            this.AutoSave30SecTool.Click += new System.EventHandler(this.AutoSave30SecTool_Click);
            // 
            // LoggerTool
            // 
            this.LoggerTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LastVerTool,
            this.AutoLogTool,
            this.SaveVerTool});
            this.LoggerTool.Name = "LoggerTool";
            this.LoggerTool.Size = new System.Drawing.Size(275, 26);
            this.LoggerTool.Text = "Журналирование";
            // 
            // LastVerTool
            // 
            this.LastVerTool.Name = "LastVerTool";
            this.LastVerTool.Size = new System.Drawing.Size(320, 26);
            this.LastVerTool.Text = "Вернуться к предыдущей версии";
            this.LastVerTool.Click += new System.EventHandler(this.LastVerTool_Click);
            // 
            // AutoLogTool
            // 
            this.AutoLogTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Loger1minTool,
            this.Loger5minTool,
            this.LoggerOff});
            this.AutoLogTool.Name = "AutoLogTool";
            this.AutoLogTool.Size = new System.Drawing.Size(320, 26);
            this.AutoLogTool.Text = "Автожурналирование";
            // 
            // Loger1minTool
            // 
            this.Loger1minTool.Name = "Loger1minTool";
            this.Loger1minTool.Size = new System.Drawing.Size(336, 26);
            this.Loger1minTool.Text = "Сохранять версию каждую минуту";
            this.Loger1minTool.Click += new System.EventHandler(this.Loger1minTool_Click);
            // 
            // Loger5minTool
            // 
            this.Loger5minTool.Name = "Loger5minTool";
            this.Loger5minTool.Size = new System.Drawing.Size(336, 26);
            this.Loger5minTool.Text = "Сохранять версию каждые 5 минут";
            this.Loger5minTool.Click += new System.EventHandler(this.Loger5minTool_Click);
            // 
            // LoggerOff
            // 
            this.LoggerOff.Name = "LoggerOff";
            this.LoggerOff.Size = new System.Drawing.Size(336, 26);
            this.LoggerOff.Text = "Выключено";
            this.LoggerOff.Click += new System.EventHandler(this.LoggerOff_Click);
            // 
            // SaveVerTool
            // 
            this.SaveVerTool.Name = "SaveVerTool";
            this.SaveVerTool.Size = new System.Drawing.Size(320, 26);
            this.SaveVerTool.Text = "Сохранить версию";
            this.SaveVerTool.Click += new System.EventHandler(this.SaveVerTool_Click);
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "file name";
            this.OpenFileDialog.Filter = "Text files (*.txt, *.rtf)|*.txt;*.rtf|C# files(*.cs)|*.cs|All files(*.*)|*.*";
            // 
            // SaveTimer
            // 
            this.SaveTimer.Enabled = true;
            this.SaveTimer.Tick += new System.EventHandler(this.SaveAllFilesTool_Click);
            // 
            // LogTimer
            // 
            this.LogTimer.Tick += new System.EventHandler(this.LogTimer_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TabControls);
            this.Controls.Add(this.MenuStrip);
            this.KeyPreview = true;
            this.MainMenuStrip = this.MenuStrip;
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.Text = "NotePad+";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.ContextMenu.ResumeLayout(false);
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TabControl TabControls;
        public System.Windows.Forms.MenuStrip MenuStrip;
        public System.Windows.Forms.ContextMenuStrip ContextMenu;
        public System.Windows.Forms.ToolStripMenuItem FielTool;
        public System.Windows.Forms.ToolStripMenuItem EditTool;
        public System.Windows.Forms.ToolStripMenuItem FormatTool;
        public System.Windows.Forms.ToolStripMenuItem SettingsTool;
        public System.Windows.Forms.ToolStripMenuItem CopyToolContextMenu;
        public System.Windows.Forms.ToolStripMenuItem OpenTool;
        public System.Windows.Forms.OpenFileDialog OpenFileDialog;
        public System.Windows.Forms.ToolStripMenuItem OpenFileNewWindowTool;
        public System.Windows.Forms.ToolStripMenuItem CloseCurrentFileTool;
        public System.Windows.Forms.ToolStripMenuItem SaveCurrentFileTool;
        public System.Windows.Forms.ToolStripMenuItem CopyTextTool;
        public System.Windows.Forms.ToolStripMenuItem PasteTextTool;
        public System.Windows.Forms.ToolStripMenuItem CutTextTool;
        public System.Windows.Forms.ToolStripMenuItem CutToolContextMenu;
        public System.Windows.Forms.ToolStripMenuItem PasteToolContextMenu;
        public System.Windows.Forms.ToolStripMenuItem SelectAllTextContextMenu;
        public System.Windows.Forms.ToolStripMenuItem SelectAllTextTool;
        public System.Windows.Forms.ToolStripMenuItem FormatToolContextMenu;
        public System.Windows.Forms.ToolStripMenuItem FormatTextTool;
        public System.Windows.Forms.FontDialog FontDialog;
        public System.Windows.Forms.ToolStripMenuItem ForegroundColoreTool;
        public System.Windows.Forms.ColorDialog ColorDialog;
        public System.Windows.Forms.ToolStripMenuItem SaveAllFilesTool;
        public System.Windows.Forms.ToolStripMenuItem CloseAppTool;
        public System.Windows.Forms.ToolStripMenuItem AutoSaveTool;
        public System.Windows.Forms.ToolStripMenuItem AutoSaveOffTool;
        public System.Windows.Forms.ToolStripMenuItem AutoSave1MinTool;
        public System.Windows.Forms.ToolStripMenuItem AutoSave5MinTool;
        public System.Windows.Forms.ToolStripMenuItem AutoSave30SecTool;
        public System.Windows.Forms.Timer SaveTimer;
        public System.Windows.Forms.ToolStripMenuItem UndoTool;
        public System.Windows.Forms.ToolStripMenuItem RedoTool;
        private System.ComponentModel.IContainer components;
        private System.Windows.Forms.FolderBrowserDialog SaveDialog;
        private System.Windows.Forms.ToolStripMenuItem CreateFileTool;
        private System.Windows.Forms.ToolStripMenuItem CreateFileNewWindowTool;
        private System.Windows.Forms.ToolStripMenuItem LoggerTool;
        private System.Windows.Forms.ToolStripMenuItem LastVerTool;
        private System.Windows.Forms.ToolStripMenuItem Loger1minTool;
        private System.Windows.Forms.ToolStripMenuItem Loger5minTool;
        private System.Windows.Forms.ToolStripMenuItem LoggerOff;
        private System.Windows.Forms.ToolStripMenuItem SaveVerTool;
        public System.Windows.Forms.ToolStripMenuItem AutoLogTool;
        private System.Windows.Forms.Timer LogTimer;
    }
}

